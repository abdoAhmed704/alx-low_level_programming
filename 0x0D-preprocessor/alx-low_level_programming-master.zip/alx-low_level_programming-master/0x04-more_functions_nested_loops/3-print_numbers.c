#include "main.h"
/**
 * print_numbers - function that prints the number
 *
*/
void print_numbers(void)
{
	char i = 0;

	for (i = '0'; i <= '9'; i++)
	{
		_putchar(i);
	}
	_putchar('\n');
}
