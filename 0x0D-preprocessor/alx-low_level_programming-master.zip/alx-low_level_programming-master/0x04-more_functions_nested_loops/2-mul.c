#include "main.h"

/**
 * mul - function that multiplies two integers.
 *
 * @i: is the first parameter
 * @j: is the socend parameter
 *
 * Return: the result.
 *
*/

int mul(int i, int j)
{
	int mul = i * j;

	return (mul);
}
