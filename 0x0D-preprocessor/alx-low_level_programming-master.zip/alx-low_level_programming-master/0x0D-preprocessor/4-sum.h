#ifndef _SUM_H
#define _SUM_H

#define SUM(a, b) ((a) + (b))

#endif /* _SUM_H */
