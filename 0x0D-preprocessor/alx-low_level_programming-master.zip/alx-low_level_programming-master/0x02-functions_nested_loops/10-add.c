
#include <stdio.h>

/**
* add - adding two numbers
* Return: sum of i and j
* @i: first number
* @j: second number
*/
int add(int i, int j)
{
	int result = i + j;

	return (result);
}
