#include <stdio.h>

/**
 * main - Entry point
 *
 * Return: Always : 1 (Success)
 */
int main(void)
{
	printf("and that piece of art is useful\" - Dora Korpar, 2015-10-19\n");
	return (1);
}
