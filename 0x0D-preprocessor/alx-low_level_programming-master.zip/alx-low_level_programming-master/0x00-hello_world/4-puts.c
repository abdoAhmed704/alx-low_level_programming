#include <stdio.h>
/**
*main - printing a sentence
*Return: 0 (success)
*/
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
