#include "main.h"

/**
 * reset_to_98 - a pointer to an int as parameter | points to 98.
 * @n: the number to modify.
 */

void reset_to_98(int *n)
{
	*n = 98;
}
